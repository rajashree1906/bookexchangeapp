package com.bookexchange.entity;

public class LoginRequest {

}
