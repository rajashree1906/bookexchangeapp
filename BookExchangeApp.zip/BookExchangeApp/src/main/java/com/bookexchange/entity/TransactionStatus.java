package com.bookexchange.entity;

public enum TransactionStatus {
    PENDING,
    ACCEPTED,
    DECLINED,
    COMPLETED,
    CANCELLED
}

