package com.bookexchange.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookexchange.entity.Message;
import com.bookexchange.entity.User;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {

	List<Message> findByReceiver(User receiver);
    // Add custom queries if needed
}

