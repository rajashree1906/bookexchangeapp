package com.bookexchange.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookexchange.entity.ExchangeRequest;
import com.bookexchange.repository.ExchangeRequestRepository;

import java.util.List;

@Service
public class ExchangeRequestService {
    
    @Autowired
    private ExchangeRequestRepository exchangeRequestRepository;

    public List<ExchangeRequest> getAllExchangeRequests() {
        return exchangeRequestRepository.findAll();
    }

    public ExchangeRequest saveExchangeRequest(ExchangeRequest exchangeRequest) {
        return exchangeRequestRepository.save(exchangeRequest);
    }

    public ExchangeRequest getExchangeRequestById(Long id) {
        return exchangeRequestRepository.findById(id).orElse(null);
    }
    
    // Add more methods as needed
}

