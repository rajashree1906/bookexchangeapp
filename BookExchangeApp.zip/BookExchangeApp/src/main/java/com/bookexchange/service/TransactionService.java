package com.bookexchange.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookexchange.entity.Transaction;
import com.bookexchange.repository.TransactionRepository;

import java.util.List;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public Transaction saveTransaction(Transaction transaction) {
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

	public Transaction getTransactionById(Long transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteTransaction(Long transactionId) {
		// TODO Auto-generated method stub
		
	}

	public List<Transaction> getTransactionsByBookId(Long bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Transaction> getTransactionsByUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

    // Add methods to update transaction status, track transaction history, etc.
}

