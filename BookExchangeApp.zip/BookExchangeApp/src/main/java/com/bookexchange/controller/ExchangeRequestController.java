package com.bookexchange.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bookexchange.entity.ExchangeRequest;
import com.bookexchange.service.ExchangeRequestService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/exchange-requests")
public class ExchangeRequestController {

    private final ExchangeRequestService exchangeRequestService;

    @Autowired
    public ExchangeRequestController(ExchangeRequestService exchangeRequestService) {
        this.exchangeRequestService = exchangeRequestService;
    }

    @GetMapping
    public ResponseEntity<List<ExchangeRequest>> getAllExchangeRequests() {
        List<ExchangeRequest> exchangeRequests = exchangeRequestService.getAllExchangeRequests();
        return ResponseEntity.ok(exchangeRequests);
    }

    @PostMapping
    public ResponseEntity<ExchangeRequest> createExchangeRequest(@RequestBody ExchangeRequest exchangeRequest) {
        ExchangeRequest savedExchangeRequest = exchangeRequestService.saveExchangeRequest(exchangeRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedExchangeRequest);
    }

    // Add more endpoints for exchange request-related operations
}

