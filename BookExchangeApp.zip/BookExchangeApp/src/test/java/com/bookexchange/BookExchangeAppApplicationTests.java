package com.bookexchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookExchangeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
